
package com.mycompany.calculadora;

/*Função de dividir*/
public class Calculadora {
    public static int dividir(int num1, int num2) {
        return num1 / num2;
    }

    /*Função de multiplicar*/
    public static int multiplicar(int num1, int num2) {
        return num1 * num2;
    }

    /*Função de somar*/
    public static int somar(int num1, int num2) {
        return num1 + num2;
    }

    /*Função de subtrair*/
    public static int subtrair(int num1, int num2) {
        return num1 - num2;
    }
}
