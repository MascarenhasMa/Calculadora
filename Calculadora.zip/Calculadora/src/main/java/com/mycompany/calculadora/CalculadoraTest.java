package com.mycompany.calculadora;

public class CalculadoraTest {
    public static void main(String[] args) {
        CalculadoraTest teste = new CalculadoraTest();
        teste.testDividir();
        teste.testMultiplicar();
        teste.testSomar();
        teste.testSubtrair();
    }

    /*Chama a função de dividir, passando numero 1 e 2*/
    public static void testDividir() {
    	// Testa a dividir de dois números positivos
        int resultado1 = Calculadora.dividir(2, 3);
        System.out.println("Resultado da divisão de 2 / 3: " + resultado1);

        // Testa a dividir de um número positivo e um negativo
        int resultado2 = Calculadora.dividir(4, -3);
        System.out.println("Resultado da divisão de 4 / (-3): " + resultado2);

     // Testa a dividir de dois números negativos
        int resultado3 = Calculadora.dividir(-5, -5);
        System.out.println("Resultado da divisão de (-5) / (-5): " + resultado3);
    }
    /*Chama a função de Multiplicar, passando numero 1 e 2*/
    public static void testMultiplicar() {
    	// Testa a multiplicar de dois números positivos
        int resultado1 = Calculadora.multiplicar(2, 3);
        System.out.println("Resultado da multiplicação de 2 * 3: " + resultado1);

     // Testa a multiplicar de um número positivo e um negativo
        int resultado2 = Calculadora.multiplicar(4, -3);
        System.out.println("Resultado da multiplicação de 4 * (-3): " + resultado2);

     // Testa a multiplicar de dois números negativos
        int resultado3 = Calculadora.multiplicar(-5, -5);
        System.out.println("Resultado da multiplicação de (-5) * (-5): " + resultado3);
    }

    /*Chama a função de somar, passando numero 1 e 2*/
    public static void testSomar() {
        // Testa a soma de dois números positivos
        int resultado1 = Calculadora.somar(2, 3);
        System.out.println("Resultado da soma de 2 + 3: " + resultado1);

        // Testa a soma de um número positivo e um negativo
        int resultado2 = Calculadora.somar(4, -3);
        System.out.println("Resultado da soma de 4 + (-3): " + resultado2);

        // Testa a soma de dois números negativos
        int resultado3 = Calculadora.somar(-5, -5);
        System.out.println("Resultado da soma de (-5) + (-5): " + resultado3);
    }

    /*Chama a função de subtrair, passando numero 1 e 2*/
    public static void testSubtrair() {
        // Testa a subtração de dois números positivos
        int resultado1 = Calculadora.subtrair(2, 3);
        System.out.println("Resultado da subtração de 2 - 3: " + resultado1);

        // Testa a subtração de um número positivo e um negativo
        int resultado2 = Calculadora.subtrair(4, -3);
        System.out.println("Resultado da subtração de 4 - (-3): " + resultado2);

        // Testa a subtração de dois números negativos
        int resultado3 = Calculadora.subtrair(-5, -5);
        System.out.println("Resultado da subtração de (-5) - (-5): " + resultado3);
    }
}

