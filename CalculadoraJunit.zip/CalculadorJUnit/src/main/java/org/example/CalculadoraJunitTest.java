package org.example;

import static org.junit.Assert.assertEquals;

import org.junit.Test;



public class CalculadoraJunitTest {

    @Test
    /*Chama a função de dividir, passando numero 1 e 2, com JUnit*/
    public void testDividir() {
        int resultado1 = Calculadora.dividir(2, 3);
        assertEquals(0, resultado1); // Espera-se que 2/3 seja 0 (divisão de inteiros)

        int resultado2 = Calculadora.dividir(4, -3);
        assertEquals(-1, resultado2); // Espera-se que 4/(-3) seja -1

        int resultado3 = Calculadora.dividir(-5, -5);
        assertEquals(1, resultado3); // Espera-se que (-5)/(-5) seja 1
    }

    @Test
    /*Chama a função de multiplicar, passando numero 1 e 2, com JUnit*/
    public void testMultiplicar() {
        int resultado1 = Calculadora.multiplicar(2, 3);
        assertEquals(6, resultado1); // Espera-se que 2*3 seja 6

        int resultado2 = Calculadora.multiplicar(4, -3);
        assertEquals(-12, resultado2); // Espera-se que 4*(-3) seja -12

        int resultado3 = Calculadora.multiplicar(-5, -5);
        assertEquals(25, resultado3); // Espera-se que (-5)*(-5) seja 25
    }

    @Test
    /*Chama a função de somar, passando numero 1 e 2, com JUnit*/
    public void testSomar() {
        int resultado1 = Calculadora.somar(2, 3);
        assertEquals(5, resultado1); // Espera-se que 2+3 seja 5

        int resultado2 = Calculadora.somar(4, -3);
        assertEquals(1, resultado2); // Espera-se que 4+(-3) seja 1

        int resultado3 = Calculadora.somar(-5, -5);
        assertEquals(-10, resultado3); // Espera-se que (-5)+(-5) seja -10
    }

    @Test
    /*Chama a função de Subtrair, passando numero 1 e 2, com JUnit*/
    public void testSubtrair() {
        int resultado1 = Calculadora.subtrair(2, 3);
        assertEquals(-1, resultado1); // Espera-se que 2-3 seja -1

        int resultado2 = Calculadora.subtrair(4, -3);
        assertEquals(7, resultado2); // Espera-se que 4-(-3) seja 7

        int resultado3 = Calculadora.subtrair(-5, -5);
        assertEquals(0, resultado3); // Espera-se que (-5)-(-5) seja 0
    }
}
